# Student Elective Subject Allocation Policy
**Fictional Policy for POC - The MoonLight Institute of Management Science**

## 1. Objective
To allocate major-specific elective subjects to students in the Postgraduate Diploma in Management (PGDM) program based on objective merit criteria, student preferences, and resource/seating capacities, avoiding any subjective bias.

## 2. Scope & Double-Major Structure
- The cohort size is approximately 350-400 students.
- At the end of Year 1, students choose two majors from five available options:
  1. Finance (FIN)
  2. Marketing (MKT)
  3. Operations (OPS)
  4. Analytics (ANA)
  5. Strategy (STR)
- Across Terms 4, 5, and 6, students take a total of 14 major-specific subjects/electives across their two selected majors (e.g., Term 4: 3 subjects per selected major, Term 5: 2 electives per selected major, Term 6: 2 electives per selected major).

## 3. Merit and Scoring Framework
To maintain absolute fairness, a common merit score is generated using deterministic scoring components:
- **Relevant first-year academic performance (50%)**: Direct academic capability from CAA records.
- **Summer internship aggregate score (20%)**: Professional performance from CSS records.
- **Case competition performance (10%)**: Standardized scores from CSS based on participation/winning.
- **Specialisation entrance test (20%)**: Standardized entrance test conducted by the Program Office.

All components must be normalized to a standard 0-100 scale before applying weights.

## 4. Capacity and Allocation Layer
- Each elective has a capacity cap, generally between 60 and 120 seats.
- Seats are allocated in descending order of merit rank list for that specific elective.
- The allocation follows a student's preference ordering (merit-preference allocation).
- Final allocations are provisional until reviewed and signed off by the Academic/Programme Authority.
