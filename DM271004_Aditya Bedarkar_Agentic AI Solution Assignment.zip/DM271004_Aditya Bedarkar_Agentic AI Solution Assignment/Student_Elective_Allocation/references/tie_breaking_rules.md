# Tie-Breaking Rules for Elective Allocation
**Fictional Rules for POC - The MoonLight Institute of Management Science**

In the event that two or more students opting for the same elective have identical Common Merit Scores, seats will be allocated by applying the following tie-breaking rules in sequential order:

1. **Step 1: Academic Performance Component Score**
   - The student with the higher normalized score in the academic performance component (50% weight) will be prioritized.
2. **Step 2: Specialisation Entrance Test Score**
   - If the tie remains, the student with the higher normalized score in the Specialisation Entrance Test (20% weight) will be prioritized.
3. **Step 3: Summer Internship Score**
   - If the tie remains, the student with the higher normalized score in the Summer Internship component (20% weight) will be prioritized.
4. **Step 4: Cumulative First-Year GPA**
   - If the tie remains, the overall first-year cumulative GPA (CGPA) will be used to break the tie.
5. **Step 5: Human-in-the-Loop Escalation**
   - In the rare event that all the above scores are identical, the system must not resolve the tie. It must flag the tie as an exception and escalate to the Academic/Programme Authority for a manual resolution decision (e.g., adding an extra seat, or allocating based on other qualitative factors).
