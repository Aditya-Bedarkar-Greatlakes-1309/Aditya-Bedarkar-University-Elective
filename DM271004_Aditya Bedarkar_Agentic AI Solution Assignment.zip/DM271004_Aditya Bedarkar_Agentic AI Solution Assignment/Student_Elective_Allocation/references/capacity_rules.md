# Capacity Rules and Constraints
**Fictional Rules for POC - The MoonLight Institute of Management Science**

## 1. Seat Capacity Limits
Each elective course has a hard seat capacity cap. 

| Elective Code | Elective Name | Major | Seat Capacity Cap |
| --- | --- | --- | --- |
| FIN-501 | Investment Management | Finance | 60 |
| FIN-502 | Commercial Banking | Finance | 60 |
| MKT-501 | Consumer Behaviour | Marketing | 120 |
| MKT-502 | Brand Management | Marketing | 120 |
| OPS-501 | Supply Chain Management | Operations | 60 |
| ANA-501 | Machine Learning for Business | Analytics | 60 |
| STR-501 | Corporate Strategy | Strategy | 60 |

## 2. Constraints Enforcement
- Under no circumstances shall the allocation script allocate more students than the capacity cap without an authorized human-in-the-loop override.
- An increase in seat cap can only be approved by the Academic/Programme Authority and must be updated in this configuration file. Individual allocations must not be edited manually; instead, a controlled rerun of the allocation algorithm must be triggered.
- Under-allocation (where an elective has fewer than 15 enrolled students) must be flagged to the Programme Office to decide if the course will run.
