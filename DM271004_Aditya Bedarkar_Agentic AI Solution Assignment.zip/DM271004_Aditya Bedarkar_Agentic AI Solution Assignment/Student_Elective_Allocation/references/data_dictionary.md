# Data Dictionary
**Fictional Rules for POC - The MoonLight Institute of Management Science**

This document describes the schema requirements for input files and output files of the Student Elective Allocation process.

## 1. Student Master & Score Data (`sample_student_data.csv`)

| Field Name | Data Type | Description | Validation Rule |
| --- | --- | --- | --- |
| `student_id` | String | Unique identifier (e.g., MLS2026001) | Must match pattern `MLS2026\d{3}` |
| `student_name` | String | Full name of the student | Cannot be null or empty |
| `major_1` | String | Selected Major 1 (FIN, MKT, OPS, ANA, STR) | Must be one of the five approved majors |
| `major_2` | String | Selected Major 2 (FIN, MKT, OPS, ANA, STR) | Must be different from major_1 |
| `gpa_year1` | Float | GPA in Year 1 subjects (on a 0-10 scale) | Range: 0.0 to 10.0 |
| `internship_score` | Float | Internship aggregate score (on a 0-100 scale) | Range: 0.0 to 100.0 |
| `case_comp_count` | Integer | Count of case competition participations | Range: >= 0 |
| `case_comp_wins` | Integer | Count of case competition wins/finalist finishes | Range: 0 to case_comp_count |
| `entrance_test_score` | Float | Specialisation entrance test score (0-50 scale) | Range: 0.0 to 50.0 |
| `pref_1` | String | First elective preference code (e.g., FIN-501) | Must belong to student's selected majors |
| `pref_2` | String | Second elective preference code (e.g., MKT-501) | Must belong to student's selected majors |
| `pref_3` | String | Third elective preference code (e.g., FIN-502) | Must belong to student's selected majors |
| `pref_4` | String | Fourth elective preference code (e.g., MKT-502) | Must belong to student's selected majors |

## 2. Calculated and Outputs Schema

### `merit_scores.csv`
- `student_id`
- `norm_academic_score` (0-100)
- `norm_internship_score` (0-100)
- `norm_case_comp_score` (0-100)
- `norm_entrance_test_score` (0-100)
- `common_merit_score` (0-100)

### `provisional_allocation.csv`
- `student_id`
- `allocated_elective_1`
- `allocated_elective_2`
- `allocation_status` (Allocated, Exception, Unallocated)
- `audit_trail_text`
