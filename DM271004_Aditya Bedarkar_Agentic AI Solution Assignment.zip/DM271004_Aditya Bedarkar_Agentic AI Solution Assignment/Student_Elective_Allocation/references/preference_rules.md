# Preference-Resolution Rules
**Fictional Rules for POC - The MoonLight Institute of Management Science**

## 1. Submission Requirements
- Students must submit a ranked list of preferences for all electives offered within their two chosen majors.
- If a student selected Majors Finance (FIN) and Marketing (MKT), they must rank all electives offered for FIN and MKT.
- Prefs must be ranked as 1, 2, 3, etc. No duplicate preference ranks are allowed.

## 2. Allocation Algorithm
- The allocation engine processes students in order of their Merit Rank (computed globally or elective-specific depending on criteria, but typically merit-first sequential matching).
- For each student, the algorithm reviews their preferences starting from Preference 1:
  - If the elective has available seats (current allocated count < seat cap), the student is allocated to that elective.
  - If the elective's capacity is exhausted, the algorithm moves to the student's Preference 2, then Preference 3, and so on.
- A student cannot be allocated to more than 2 electives per term per major (totaling 4 electives in Term 5 and Term 6), as specified in the Academic Structure.
- If a student cannot be allocated to any of their preferences due to capacity constraints, they are placed in a "Unallocated" pool, which is raised as a system exception for human-in-the-loop manual placement.
