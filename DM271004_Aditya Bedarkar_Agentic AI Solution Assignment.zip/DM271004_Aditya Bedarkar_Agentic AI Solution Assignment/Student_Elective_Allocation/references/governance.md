# Governance and RACI Matrix
**Fictional Rules for POC - The MoonLight Institute of Management Science**

## 1. RACI Matrix

| Phase / Activity | Students | CAA | CSS | Program Office | Academic Authority | Agentic AI System |
| --- | --- | --- | --- | --- | --- | --- |
| Publish Policy & Caps | I | C | C | C | A / R | C |
| Data Collection / Entry | C | R | R | R | A | I |
| Data Consolidation & Validation | I | C | C | C | A | R |
| Score & Merit Calculation | I | I | I | I | A | R (via scripts) |
| Ranking & Provisional Allocation | I | I | I | I | A | R (via scripts) |
| Review Exceptions / Overrides | C | C | C | C | A / R | I |
| Final Approval & Publication | I | I | I | I | A / R | I |
| Grievance Redressal | C | C | C | C | A / R | I |

*R = Responsible, A = Accountable, C = Consulted, I = Informed*

## 2. Decision Boundaries and Mandatory Human-in-the-Loop Interventions
- The Agentic AI System must run allocations and validations, but is strictly prohibited from executing final allocations autonomously.
- **Mandatory Human-in-the-Loop approval triggers**:
  - Overriding any student allocation.
  - Adding capacity to any course.
  - Resolving unallocated student cases.
  - Adjusting policy weightages or tie-breaker logic.
  - Resolving data discrepancies (e.g., student disputing GPA).
