import sys
import os
import csv
import re

def validate_data(input_csv, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    exceptions_path = os.path.join(output_dir, 'exceptions.csv')
    clean_data_path = os.path.join(output_dir, 'clean_student_data.csv')
    
    valid_majors = {'FIN', 'MKT', 'OPS', 'ANA', 'STR'}
    
    exceptions = []
    clean_records = []
    
    headers = []
    with open(input_csv, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames
        for row in reader:
            student_id = row['student_id']
            errors = []
            
            # Validate student ID
            if not re.match(r'^MLS2026\d{3}$', student_id):
                errors.append(f"Invalid student ID format: {student_id}")
            
            # Validate majors
            m1 = row['major_1']
            m2 = row['major_2']
            if m1 not in valid_majors:
                errors.append(f"Invalid Major 1: {m1}")
            if m2 not in valid_majors:
                errors.append(f"Invalid Major 2: {m2}")
            if m1 == m2:
                errors.append(f"Duplicate majors selected: {m1} and {m2}")
                
            # Validate GPA
            try:
                gpa = float(row['gpa_year1'])
                if not (0.0 <= gpa <= 10.0):
                    errors.append(f"GPA out of range (0-10): {gpa}")
            except ValueError:
                errors.append(f"GPA is not a float: {row['gpa_year1']}")
                
            # Validate Internship Score
            try:
                intern_score = float(row['internship_score'])
                if not (0.0 <= intern_score <= 100.0):
                    errors.append(f"Internship score out of range (0-100): {intern_score}")
            except ValueError:
                errors.append(f"Internship score is not a float: {row['internship_score']}")
                
            # Validate Case Comp count and wins
            try:
                cc_count = int(row['case_comp_count'])
                cc_wins = int(row['case_comp_wins'])
                if cc_count < 0:
                    errors.append(f"Case competition count cannot be negative: {cc_count}")
                if cc_wins < 0 or cc_wins > cc_count:
                    errors.append(f"Case competition wins must be between 0 and count: {cc_wins} of {cc_count}")
            except ValueError:
                errors.append("Case competition fields must be integers")
                
            # Validate Entrance Test Score
            if not row['entrance_test_score']:
                errors.append("Entrance test score is missing")
            else:
                try:
                    et_score = float(row['entrance_test_score'])
                    if not (0.0 <= et_score <= 50.0):
                        errors.append(f"Entrance test score out of range (0-50): {et_score}")
                except ValueError:
                    errors.append(f"Entrance test score is not a float: {row['entrance_test_score']}")
            
            # Validate Preferences belong to selected majors
            prefs = [row['pref_1'], row['pref_2'], row['pref_3'], row['pref_4']]
            for idx, pref in enumerate(prefs, 1):
                if not pref:
                    errors.append(f"Preference {idx} is empty")
                else:
                    pref_prefix = pref.split('-')[0]
                    if pref_prefix not in [m1, m2]:
                        errors.append(f"Preference {idx} ({pref}) does not belong to selected majors [{m1}, {m2}]")
            
            if errors:
                row['validation_errors'] = "; ".join(errors)
                exceptions.append(row)
                print(f"Exception detected for {student_id}: {errors}")
            else:
                clean_records.append(row)
                
    # Write clean records
    with open(clean_data_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(clean_records)
        
    # Write exceptions
    with open(exceptions_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers + ['validation_errors'])
        writer.writeheader()
        writer.writerows(exceptions)
        
    print(f"Validation complete. Clean records: {len(clean_records)}, Exceptions: {len(exceptions)}")

if __name__ == '__main__':
    # Default paths for execution
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    input_csv = os.path.join(base_dir, 'assets', 'sample_student_data.csv')
    output_dir = os.path.join(base_dir, 'output', 'exceptions')
    validate_data(input_csv, output_dir)
