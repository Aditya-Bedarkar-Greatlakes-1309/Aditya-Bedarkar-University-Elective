import sys
import os
import csv

def calculate_merit(clean_csv, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    merit_scores_path = os.path.join(output_dir, 'merit_scores.csv')
    
    # Weightages as per config: 50% Academics, 20% Internship, 10% Case Comp, 20% Entrance Test
    W_ACAD = 0.50
    W_INTERN = 0.20
    W_CASE = 0.10
    W_ET = 0.20
    
    calculated_records = []
    
    with open(clean_csv, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            student_id = row['student_id']
            
            # 1. Academics: GPA (0-10) -> Normalised (0-100)
            gpa = float(row['gpa_year1'])
            norm_acad = gpa * 10.0
            
            # 2. Internship: score (0-100) -> Already (0-100)
            norm_intern = float(row['internship_score'])
            
            # 3. Case Competition Score:
            # 20 points per participation, 40 points per win, capped at 100 points
            cc_count = int(row['case_comp_count'])
            cc_wins = int(row['case_comp_wins'])
            case_score = (cc_count * 20.0) + (cc_wins * 40.0)
            norm_case = min(case_score, 100.0)
            
            # 4. Entrance Test Score (0-50) -> Normalised (0-100)
            et = float(row['entrance_test_score'])
            norm_et = et * 2.0
            
            # Common Merit Score calculation
            common_merit_score = (norm_acad * W_ACAD) + (norm_intern * W_INTERN) + (norm_case * W_CASE) + (norm_et * W_ET)
            
            calc_row = {
                'student_id': student_id,
                'student_name': row['student_name'],
                'major_1': row['major_1'],
                'major_2': row['major_2'],
                'norm_acad': norm_acad,
                'norm_intern': norm_intern,
                'norm_case': norm_case,
                'norm_et': norm_et,
                'common_merit_score': round(common_merit_score, 4),
                'pref_1': row['pref_1'],
                'pref_2': row['pref_2'],
                'pref_3': row['pref_3'],
                'pref_4': row['pref_4']
            }
            calculated_records.append(calc_row)
            
    headers = [
        'student_id', 'student_name', 'major_1', 'major_2', 
        'norm_acad', 'norm_intern', 'norm_case', 'norm_et', 
        'common_merit_score', 'pref_1', 'pref_2', 'pref_3', 'pref_4'
    ]
    
    with open(merit_scores_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(calculated_records)
        
    print(f"Merit calculation complete. Calculated scores saved to {merit_scores_path}")

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    clean_csv = os.path.join(base_dir, 'output', 'exceptions', 'clean_student_data.csv')
    output_dir = os.path.join(base_dir, 'output', 'provisional')
    if os.path.exists(clean_csv):
        calculate_merit(clean_csv, output_dir)
    else:
        print("Clean student data not found. Please run validation first.")
