import sys
import os
import csv

def allocate_electives(ranked_csv, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    allocation_path = os.path.join(output_dir, 'provisional_allocation.csv')
    
    # Define capacities (For POC, we set low capacities to test enforcement)
    capacities = {
        'FIN-501': 2, # Low cap to demonstrate capacity limit and preference shifting
        'FIN-502': 10,
        'MKT-501': 10,
        'MKT-502': 10,
        'OPS-501': 5,
        'ANA-501': 5,
        'STR-501': 5
    }
    
    allocations = {} # student_id -> list of allocated courses (max 2)
    course_enrollments = {course: [] for course in capacities}
    
    students = []
    with open(ranked_csv, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            row['global_rank'] = int(row['global_rank'])
            students.append(row)
            
    # Sequential allocation by rank
    for student in students:
        s_id = student['student_id']
        allocations[s_id] = []
        
        prefs = [student['pref_1'], student['pref_2'], student['pref_3'], student['pref_4']]
        
        audit_trail = []
        # Attempt to allocate up to 2 electives
        for pref in prefs:
            if not pref:
                continue
            if len(allocations[s_id]) >= 2:
                break
                
            current_enrolled = len(course_enrollments.get(pref, []))
            cap = capacities.get(pref, 60) # Default to 60 if not specified
            
            if current_enrolled < cap:
                # Check for double-major limits (max 1 course of the same code)
                if pref not in allocations[s_id]:
                    course_enrollments[pref].append(s_id)
                    allocations[s_id].append(pref)
                    audit_trail.append(f"Allocated {pref} (Rank: {student['global_rank']})")
            else:
                audit_trail.append(f"Skipped {pref} due to capacity limit ({current_enrolled}/{cap} filled)")
                
        # Fill missing allocation status
        status = "Allocated"
        if len(allocations[s_id]) < 2:
            status = "Unallocated" if len(allocations[s_id]) == 0 else "Partially Allocated"
            audit_trail.append("Alert: Seat capacity exhausted for preference list; manual resolution needed.")
            
        student['allocated_elective_1'] = allocations[s_id][0] if len(allocations[s_id]) > 0 else 'None'
        student['allocated_elective_2'] = allocations[s_id][1] if len(allocations[s_id]) > 1 else 'None'
        student['allocation_status'] = status
        student['audit_trail_text'] = " -> ".join(audit_trail)
        
    headers = [
        'global_rank', 'student_id', 'student_name', 'major_1', 'major_2',
        'allocated_elective_1', 'allocated_elective_2', 'allocation_status', 'audit_trail_text'
    ]
    
    with open(allocation_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(students)
        
    print(f"Allocation complete. Provisional allocations saved to {allocation_path}")
    print("Seat counts:")
    for course, list_students in course_enrollments.items():
        print(f"  {course}: {len(list_students)} / {capacities.get(course)}")

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ranked_csv = os.path.join(base_dir, 'output', 'provisional', 'ranked_students.csv')
    output_dir = os.path.join(base_dir, 'output', 'provisional')
    if os.path.exists(ranked_csv):
        allocate_electives(ranked_csv, output_dir)
    else:
        print("Ranked students list not found. Run ranking first.")
