import sys
import os
import csv

def validate_allocation(allocation_csv, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    violations_path = os.path.join(output_dir, 'allocation_violations.csv')
    
    # Capacities definition
    capacities = {
        'FIN-501': 2,
        'FIN-502': 10,
        'MKT-501': 10,
        'MKT-502': 10,
        'OPS-501': 5,
        'ANA-501': 5,
        'STR-501': 5
    }
    
    violations = []
    course_counts = {course: 0 for course in capacities}
    
    with open(allocation_csv, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            s_id = row['student_id']
            m1 = row['major_1']
            m2 = row['major_2']
            e1 = row['allocated_elective_1']
            e2 = row['allocated_elective_2']
            
            errors = []
            
            # Check major compliance for Elective 1
            if e1 != 'None':
                course_counts[e1] = course_counts.get(e1, 0) + 1
                pref_1_prefix = e1.split('-')[0]
                if pref_1_prefix not in [m1, m2]:
                    errors.append(f"Elective 1 ({e1}) does not belong to selected majors [{m1}, {m2}]")
                    
            # Check major compliance for Elective 2
            if e2 != 'None':
                course_counts[e2] = course_counts.get(e2, 0) + 1
                pref_2_prefix = e2.split('-')[0]
                if pref_2_prefix not in [m1, m2]:
                    errors.append(f"Elective 2 ({e2}) does not belong to selected majors [{m1}, {m2}]")
                    
            # Check duplicate courses
            if e1 != 'None' and e1 == e2:
                errors.append(f"Duplicate allocation: {e1}")
                
            if errors:
                row['violation_details'] = "; ".join(errors)
                violations.append(row)
                
        # Check capacity violations
        for course, count in course_counts.items():
            cap = capacities.get(course, 60)
            if count > cap:
                violations.append({
                    'student_id': 'SYSTEM',
                    'student_name': 'SYSTEM_CAPACITY_CHECK',
                    'major_1': '',
                    'major_2': '',
                    'allocated_elective_1': course,
                    'allocated_elective_2': '',
                    'allocation_status': 'EXCEPTION',
                    'violation_details': f"Course {course} exceeds capacity cap: {count} allocated (cap is {cap})"
                })
                
    headers = [
        'global_rank', 'student_id', 'student_name', 'major_1', 'major_2',
        'allocated_elective_1', 'allocated_elective_2', 'allocation_status', 'violation_details'
    ]
    
    with open(violations_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(violations)
        
    print(f"Validation complete. Allocation violations: {len(violations)}")

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    allocation_csv = os.path.join(base_dir, 'output', 'provisional', 'provisional_allocation.csv')
    output_dir = os.path.join(base_dir, 'output', 'exceptions')
    if os.path.exists(allocation_csv):
        validate_allocation(allocation_csv, output_dir)
    else:
        print("Provisional allocation file not found.")
