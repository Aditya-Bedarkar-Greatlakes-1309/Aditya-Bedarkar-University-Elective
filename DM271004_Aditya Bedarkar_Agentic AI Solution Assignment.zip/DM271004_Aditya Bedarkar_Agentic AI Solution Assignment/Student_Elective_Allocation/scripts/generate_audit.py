import sys
import os
import csv

def generate_audit(allocation_csv, exceptions_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    audit_summary_path = os.path.join(output_dir, 'audit_summary_report.txt')
    
    total_students = 0
    fully_allocated = 0
    partially_allocated = 0
    unallocated = 0
    
    allocations_details = []
    
    with open(allocation_csv, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_students += 1
            status = row['allocation_status']
            if status == 'Allocated':
                fully_allocated += 1
            elif status == 'Partially Allocated':
                partially_allocated += 1
            elif status == 'Unallocated':
                unallocated += 1
            allocations_details.append(row)
            
    # Read validation and exception counts
    exception_count = 0
    ex_file = os.path.join(exceptions_dir, 'exceptions.csv')
    if os.path.exists(ex_file):
        with open(ex_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            exception_count = sum(1 for r in reader)
            
    violation_count = 0
    vi_file = os.path.join(exceptions_dir, 'allocation_violations.csv')
    if os.path.exists(vi_file):
        with open(vi_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            violation_count = sum(1 for r in reader)

    report_text = f"""========================================================================
STUDENT ELECTIVE ALLOCATION AUDIT & SUMMARY REPORT
========================================================================
Fictional Report for POC - The MoonLight Institute of Management Science
Date: 2026-08-18 (System Run)

1. COHORT SUMMARY METRICS:
---------------------------------------------
Total Students Processed: {total_students}
- Fully Allocated (2 Courses): {fully_allocated}
- Partially Allocated (1 Course): {partially_allocated}
- Unallocated (0 Courses): {unallocated}

Data Validation Exceptions (Missing/Invalid Source Data): {exception_count}
Allocation Violations (Policy/Capacity Deviations): {violation_count}

2. DETAILED EXCEPTION LIST & STATUS FLAGS:
---------------------------------------------
Students flagged with anomalies or missing course selections:
"""
    if exception_count > 0:
        with open(ex_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                report_text += f"- Student ID: {row['student_id']} | Name: {row['student_name']} | Details: {row['validation_errors']}\n"
    else:
        report_text += "No source data exceptions found.\n"
        
    report_text += "\n3. SYSTEM DETECTED ALLOCATION VIOLATIONS:\n---------------------------------------------\n"
    if violation_count > 0:
        with open(vi_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                report_text += f"- ID: {row['student_id']} | Name: {row['student_name']} | Violation: {row['violation_details']}\n"
    else:
        report_text += "No allocation policy or capacity violations detected.\n"
        
    report_text += "\n4. COMPLIANCE & HUMAN APPROVAL SIGN-OFF:\n---------------------------------------------\n"
    report_text += "Status: PENDING REVIEW\n"
    report_text += "Orchestration version: 1.0 (Agentic AI - Moonlight Institute)\n"
    report_text += "Sign-off Authority: Academic / Programme Authority\n"
    report_text += "Signature: __________________________    Date: ______________\n"
    report_text += "========================================================================\n"
    
    with open(audit_summary_path, mode='w', encoding='utf-8') as f:
        f.write(report_text)
        
    print(f"Audit report generated successfully at {audit_summary_path}")

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    allocation_csv = os.path.join(base_dir, 'output', 'provisional', 'provisional_allocation.csv')
    exceptions_dir = os.path.join(base_dir, 'output', 'exceptions')
    output_dir = os.path.join(base_dir, 'output', 'audit')
    if os.path.exists(allocation_csv):
        generate_audit(allocation_csv, exceptions_dir, output_dir)
    else:
        print("Provisional allocation CSV not found.")
