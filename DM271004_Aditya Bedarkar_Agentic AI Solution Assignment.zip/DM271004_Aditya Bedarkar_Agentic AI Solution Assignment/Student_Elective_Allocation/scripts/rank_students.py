import sys
import os
import csv

def rank_students(merit_csv, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    ranked_csv_path = os.path.join(output_dir, 'ranked_students.csv')
    
    records = []
    with open(merit_csv, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Parse floats for tie-breaking comparison
            row['common_merit_score'] = float(row['common_merit_score'])
            row['norm_acad'] = float(row['norm_acad'])
            row['norm_et'] = float(row['norm_et'])
            row['norm_intern'] = float(row['norm_intern'])
            records.append(row)
            
    # Sort key: 
    # Primary: common_merit_score (descending)
    # Secondary: norm_acad (descending)
    # Tertiary: norm_et (descending)
    # Quaternary: norm_intern (descending)
    records.sort(
        key=lambda x: (
            -x['common_merit_score'],
            -x['norm_acad'],
            -x['norm_et'],
            -x['norm_intern'],
            x['student_id'] # Fallback string ordering
        )
    )
    
    # Assign global ranks
    for rank, row in enumerate(records, 1):
        row['global_rank'] = rank
        
    headers = [
        'global_rank', 'student_id', 'student_name', 'major_1', 'major_2',
        'norm_acad', 'norm_intern', 'norm_case', 'norm_et',
        'common_merit_score', 'pref_1', 'pref_2', 'pref_3', 'pref_4'
    ]
    
    with open(ranked_csv_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(records)
        
    print(f"Ranking complete. Ranked students list saved to {ranked_csv_path}")

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    merit_csv = os.path.join(base_dir, 'output', 'provisional', 'merit_scores.csv')
    output_dir = os.path.join(base_dir, 'output', 'provisional')
    if os.path.exists(merit_csv):
        rank_students(merit_csv, output_dir)
    else:
        print("Merit scores not found. Run merit calculation first.")
