---
name: Student_Elective_Allocation
description: Orchestrates student elective allocation for double-major specialisation at The MoonLight Institute of Management Science.
version: 1.0.0
allowed_tools:
  - run_command
  - list_dir
  - view_file
  - write_to_file
---

# Student Elective Subject Allocation Skill

## Purpose & Scope
This skill provides the execution logic and guardrails for coordinating the elective subject allocation process for PGDM double-major specialisations at **The Moonlight Institute of Management Science**. It orchestrates exactly 5 logical agents and invokes deterministic scripts for scoring, ranking, and capacity checks, ensuring humans retain final authority and mathematical results remain objective.

## Inputs & Outputs

### Inputs
1. `student_data`: Path to the raw CSV containing student master records and preferences. Default is `assets/sample_student_data.csv`.
2. `policy_pack`: Directory path containing the rules and configurations (weights, eligibility, tie-breakers). Default is `references/`.

### Outputs
1. `clean_student_data.csv`: Validated student entries ready for calculations.
2. `exceptions.csv`: Flagged invalid records requiring manual correction.
3. `merit_scores.csv`: Calculated and normalized merit scores.
4. `ranked_students.csv`: global rankings with tie-breakers applied.
5. `provisional_allocation.csv`: Output allocations.
6. `audit_summary_report.txt`: Compliance sign-off and summary report.

## Step-by-Step Execution Instructions

The Orchestrator Agent must execute the allocation process in the following sequential order:

```mermaid
graph TD
    A[Start: Authenticate & Setup Cycle] --> B[Load Approved Policy Pack]
    B --> C[Retrieve & Validate Authorised Data]
    C --> D{Data Exceptions?}
    D -- Yes --> E[Escalate to Human & Log Exception]
    D -- No --> F[Normalise & Compute Merit Score via Script]
    F --> G[Rank Students via Tie-Breaking Rules Script]
    G --> H[Allocate Electives via Capacity Engine Script]
    H --> I[Validate Allocation Compliance]
    I --> J{Violations Detected?}
    J -- Yes --> K[Escalate Violation to Human]
    J -- No --> L[Generate Provisional Allocation & Audit Trail]
    L --> M[Awaiting Human final Sign-Off]
    M --> N[Publish & Lock Allocation Cycle]
```

### 1. Establish Cycle and Validate Configuration
- **Action**: Authenticate the user and establish the allocation cycle identifier (e.g., `FALL_2026_CYCLE_V1`).
- **Orchestrator Role**: Load and review `references/policy.md` and `references/weightage_config.yaml`.
- **Validation**: Confirm weightages sum exactly to 1.0 (50% Academics, 20% Internship, 10% Case Competition, 20% Entrance Test). If inconsistent, stop execution and alert the human administrator.

### 2. Retrieve & Clean Source Data
- **Action**: Invoke `scripts/validate_data.py` on the raw student csv.
- **Orchestrator Role**: Pass output exceptions to the Policy & Data Validation Agent to generate the exception list.
- **Guardrail**: If exceptions are found, alert the Human-in-the-Loop to fix source data in CSS/CAA; do not proceed with calculation.

### 3. Calculate Score and Rank
- **Action**: Run `scripts/calculate_merit.py` on `clean_student_data.csv`.
- **Action**: Run `scripts/rank_students.py` to assign global rankings.
- **Orchestrator Role**: Ground calculations in the deterministic scripts. The LLM must NEVER perform math/calculations.

### 4. Allocate Electives and Enforce Caps
- **Action**: Run `scripts/allocate_electives.py` to match preferences and enforce seat caps.
- **Action**: Run `scripts/validate_allocation.py` to check for major mismatches, duplicate courses, or capacity overages.
- **Orchestrator Role**: Flag any unallocated students or compliance issues.

### 5. Final Approval and Audit
- **Action**: Run `scripts/generate_audit.py` to output the final package.
- **Orchestrator Role**: Submit `audit_summary_report.txt` and `provisional_allocation.csv` to the Academic Authority.
- **Guardrail**: Do NOT publish results automatically. Lock the file version only after receiving verified human approval.

## Guardrails & Edge Cases

- **Missing/Conflicting Data**: Flag immediately in `exceptions/exceptions.csv`. The Policy & Data Validation Agent must not attempt to impute or guess missing values.
- **Deterministic Separation**: Math, scores, ranking, and capacity validations are strictly restricted to scripts. LLM is prohibited from editing scores or seat allocation matrices.
- **Hallucination Prevention**: If a policy rule is not documented in the `references/` folder, the agent must report "Ambiguity Detected" and halt execution, requesting a human update.
